<nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">


    <!--Admin Top Navigation-->

    <?php echo $__env->make('includes.admin_top_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



    <!--Admin side navigation-->

   <?php echo $__env->make('includes.admin_side_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



    <!-- /.navbar-static-side -->
</nav>
