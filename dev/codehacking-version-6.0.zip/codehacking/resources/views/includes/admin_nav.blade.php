<nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">


    <!--Admin Top Navigation-->

    @include('includes.admin_top_nav')



    <!--Admin side navigation-->

   @include('includes.admin_side_nav')



    <!-- /.navbar-static-side -->
</nav>
